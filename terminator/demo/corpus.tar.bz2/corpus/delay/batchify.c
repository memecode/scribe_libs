#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char j[100000][10], f[100000][100],cmd[1000];
int batch,i,k,m,n,nham,nspam;

main(int argc, char **argv){
   if (argc == 2) srand(atoi(argv[1]));
   for (n=0;2 == scanf("%s%s",j[n],f[n]);n++){}
   while (i < n) {
      if (!strcmp(j[i],"ham")) nham++;
      if (!strcmp(j[i],"spam")) nspam++;
      if (nspam < 10 || nham < 10) batch = 1;
      else batch = 200 * -log(random()/(double)RAND_MAX); 
      for (k=0;k<batch && i+k<n;k++) {
         if (!strcmp(j[i+k],"spam")) printf("Spam %s\n",f[i+k]);
         else printf("Ham %s\n",f[i+k]);
      }
      for (k=0;k<batch && i+k<n;k++) {
         if (!strcmp(j[i+k],"spam")) printf("SPAM %s\n",f[i+k]);
         else printf("HAM %s\n",f[i+k]);
      }
      i += k;
   }
}
